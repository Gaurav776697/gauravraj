playerInGame = false;
blackJackState = false;


let myCards = [];
let sumCard = 0;

let callMsg = document.getElementById("description");
let callSum = document.getElementById("card-sum");
let callCards = document.getElementById("my-cards")


function randomCard () {
    let cardRandom = Math.floor(Math.random()*12)+1;
    if (cardRandom === 1) {
        return 11
    }else if (cardRandom > 10) {
        return 10
    }else {
        return cardRandom
    }
}
function gameStart () {
    playerInGame = true;
    let card1 = randomCard();
    let card2 = randomCard();
    myCards = [card1, card2];
    sumCard = card1 + card2
    gameFunction()
}

function gameFunction () {

    callCards.textContent = "Your Cards Are: "
    for(i=0; i<myCards.length; i++) {
       callCards.textContent += myCards[i] + " "
    }
    if (sumCard <=20) {
        callMsg.textContent = "Wow!! Your Card Sum is " + sumCard + ", Draw Another Card";
        playerInGame = true;
        blackJackState = false;
        document.getElementById("start-game").textContent = "Draw Again"
        document.getElementById("draw-card").textContent = "Draw Another Card"
    } 


    else if (sumCard === 21) {
        document.getElementById("description").textContent = "Yoo!! The Card Sum is " + sumCard + ", You Have The Black Jack";
        callSum.textContent = sumCard;
        playerInGame = false;
        blackJackState = true;
        document.getElementById("start-game").textContent = "Black Jack"
    }


    else if (sumCard >21) {
        document.getElementById("description").textContent = "OHH NO! The Card Sum is " + sumCard + ", You are Out of the Game";
        callSum.textContent = sumCard;
        playerInGame = false;
        blackJackState = false;
        document.getElementById("start-game").textContent = "Start New Game "
        document.getElementById("draw-card").textContent = "Game Over"
    }

    callSum.textContent = "Card Sum: " + sumCard;
}

function drawACard () {
    if (blackJackState === false && playerInGame === true) {
    let drawnCard = randomCard();
    myCards.push(drawnCard);
    sumCard += drawnCard
    gameFunction()
    }
}