
    setInterval(() => {
        document.querySelector(".name1").innerText = "Web Designer"
    }, 2000);
    setInterval(() => {
        document.querySelector(".name1").innerText = "Web Devloper"
    }, 4000); 
    setInterval(() => {
        document.querySelector(".name1").innerText = "Gaurav Raj"
    }, 6000); 

