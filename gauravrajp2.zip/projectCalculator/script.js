let opratorSelectedState = false
let equalSate = false;
function btn1 () {
    document.querySelector(".snum").textContent += 1;
};
function btn2 () {
    document.querySelector(".snum").textContent += 2;
};
function btn3 () {
    document.querySelector(".snum").textContent += 3;
};
function btn4 () {
    document.querySelector(".snum").textContent += 4;
};
function btn5 () {
    document.querySelector(".snum").textContent += 5;
};
function btn6 () {
    document.querySelector(".snum").textContent += 6;
};
function btn7 () {
    document.querySelector(".snum").textContent += 7;
};
function btn8 () {
    document.querySelector(".snum").textContent += 8;
};
function btn9 () {
    document.querySelector(".snum").textContent += 9;
};
function btn0 () {
    document.querySelector(".snum").textContent += 0;
};
function btndot () { if (!document.querySelector(".snum").textContent.includes("."))
    document.querySelector(".snum").textContent += ".";
};

function appendPluse (){ if (!document.querySelector(".fnum").textContent.includes("+")) { 
    document.querySelector(".fnum").textContent += document.querySelector(".snum").textContent + " " + "+" + " ";
    document.querySelector(".snum").textContent = " "
}    
}

function appendMinus(){ if (!document.querySelector(".fnum").textContent.includes("-")) { 
    document.querySelector(".fnum").textContent += document.querySelector(".snum").textContent + " " + "-" + " ";
    document.querySelector(".snum").textContent = " "
}
}

function appendDevide (){ if (!document.querySelector(".fnum").textContent.includes("/")) {
    document.querySelector(".fnum").textContent += document.querySelector(".snum").textContent + " " + "/" + " ";
    document.querySelector(".snum").textContent = " "
}
}

function appendMultiply (){ if (!document.querySelector(".fnum").textContent.includes("*")) {
    document.querySelector(".fnum").textContent += document.querySelector(".snum").textContent + " " + "*" + " ";
    document.querySelector(".snum").textContent = " "
}
}

function allClear () {
    document.querySelector(".fnum").textContent = " "
    document.querySelector(".snum").textContent = " "
    equalSate = false;
}

function equal () { if (equalSate === false) {
    document.querySelector(".fnum").textContent += document.querySelector(".snum").textContent
    document.querySelector(".snum").textContent = eval(document.querySelector(".fnum").textContent)
    equalSate = true;
}
}

function del () {
    document.querySelector(".snum").textContent = document.querySelector(".snum").textContent.substr(0,document.querySelector(".snum").textContent.length-1)
}